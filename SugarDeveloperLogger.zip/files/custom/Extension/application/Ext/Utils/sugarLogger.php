<?php
//SugarDeveloperLogger
LoggerManager::setLogger('fatal', 'SugarDeveloperLogger');
LoggerManager::setLogger('error', 'SugarDeveloperLogger');
LoggerManager::setLogger('security', 'SugarDeveloperLogger');
LoggerManager::setLogger('deprecated', 'SugarDeveloperLogger');
